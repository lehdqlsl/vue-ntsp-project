self.__precacheManifest = [
  {
    "revision": "5b80a6b0be18889f7bcc",
    "url": "/css/app.275984ec.css"
  },
  {
    "revision": "5b80a6b0be18889f7bcc",
    "url": "/js/app.a7664351.js"
  },
  {
    "revision": "e2d928018cb3ba2a805c",
    "url": "/js/chunk-2d219ff9.0aab29fd.js"
  },
  {
    "revision": "422b975fee7e44b52887",
    "url": "/css/chunk-3e21d2e0.8b99b02b.css"
  },
  {
    "revision": "422b975fee7e44b52887",
    "url": "/js/chunk-3e21d2e0.b1a98183.js"
  },
  {
    "revision": "44504bf3d0eac05f42a9",
    "url": "/css/chunk-4fac0c8f.77d8fbd9.css"
  },
  {
    "revision": "44504bf3d0eac05f42a9",
    "url": "/js/chunk-4fac0c8f.f384e950.js"
  },
  {
    "revision": "0734f350975788f6013e",
    "url": "/css/chunk-954612da.dca96c3f.css"
  },
  {
    "revision": "0734f350975788f6013e",
    "url": "/js/chunk-954612da.e21d1b49.js"
  },
  {
    "revision": "a91868b92e4b11603c9d",
    "url": "/css/chunk-vendors.86d902de.css"
  },
  {
    "revision": "a91868b92e4b11603c9d",
    "url": "/js/chunk-vendors.2beb5209.js"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "ff208b8d733e61a630992ee2b72c9c1c",
    "url": "/fonts/nucleo-icons.ff208b8d.woff2"
  },
  {
    "revision": "8224e0160e362e117cbe00495919e2af",
    "url": "/fonts/nucleo-icons.8224e016.eot"
  },
  {
    "revision": "b0dc05d015e91e7d28d79cd0056fe555",
    "url": "/fonts/nucleo-icons.b0dc05d0.ttf"
  },
  {
    "revision": "ae42fa524981a56f3f289447cff36eb1",
    "url": "/img/nucleo-icons.ae42fa52.svg"
  },
  {
    "revision": "43b53f6d036925a727fac03e9eef8a00",
    "url": "/index.html"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/.gitkeep"
  },
  {
    "revision": "996d8248f580f8e26e6c45c67da9b5a6",
    "url": "/favicon.png"
  },
  {
    "revision": "a9615bac158705203261e8348f574cc8",
    "url": "/img/faces/face-0.jpg"
  },
  {
    "revision": "a9615bac158705203261e8348f574cc8",
    "url": "/img/default-avatar.png"
  },
  {
    "revision": "99e58416b89637502b40ac8350eed85a",
    "url": "/img/faces/face-1.jpg"
  },
  {
    "revision": "4ab22eca4053c14a34e4bdb6390deae9",
    "url": "/img/faces/face-5.jpg"
  },
  {
    "revision": "ce7a6b79aa55041f7ae36f6ce22231fe",
    "url": "/img/faces/face-3.jpg"
  },
  {
    "revision": "0b68eb8f1cde1fc9987a9196df05b96a",
    "url": "/img/faces/face-4.jpg"
  },
  {
    "revision": "0e953b1ea6d6e3addd7210e9c7c420a7",
    "url": "/img/faces/face-2.jpg"
  },
  {
    "revision": "4b87e628f4ef9988718860890b2a682f",
    "url": "/img/faces/face-6.jpg"
  },
  {
    "revision": "be74132f42ae1d3502f9a9b9fff68ac1",
    "url": "/Dashboard.PNG"
  },
  {
    "revision": "bf1684a30a86ba1b222aab3acff16356",
    "url": "/img/faces/face-7.jpg"
  },
  {
    "revision": "996d8248f580f8e26e6c45c67da9b5a6",
    "url": "/img/favicon.png"
  },
  {
    "revision": "43b98081492ac3bcb4a1fac6cf709403",
    "url": "/img/faces/tim_vector.jpe"
  },
  {
    "revision": "5ae5691c161e0f37f8478425e62cf4ac",
    "url": "/img/faces/face-old.jpg"
  },
  {
    "revision": "794ba902634db032e8abc6eec745d0ca",
    "url": "/img/faces/face-10.jpg"
  },
  {
    "revision": "0a337c37f03c0462996b7b03758fa72b",
    "url": "/img/loading-bubbles.svg"
  },
  {
    "revision": "d27fbc90c2e644dfdc9765640dc713b9",
    "url": "/img/mask.png"
  },
  {
    "revision": "7a4ce7cc040fc1cb8176cde106e9232f",
    "url": "/img/sidebar-2.jpg"
  },
  {
    "revision": "6be21e8a1b7d63048728851c6003e189",
    "url": "/img/sidebar-1.jpg"
  },
  {
    "revision": "cd253e23ed052deeb80b42d2ed772183",
    "url": "/img/sidebar-3.jpg"
  },
  {
    "revision": "f575a04ebbb31b5798a4c54783e745a2",
    "url": "/img/new_logo.png"
  },
  {
    "revision": "897b4cf909210560a84398d36da51983",
    "url": "/img/sidebar-4.jpg"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "44bf13a71a4db6e15913fe8af9296711",
    "url": "/img/tim_80x80.png"
  },
  {
    "revision": "c2a605fbc0e687b2e1b4b90a7c445cdd",
    "url": "/img/vue-logo.png"
  },
  {
    "revision": "9ebea76ee1225f00d882b21547a7b49f",
    "url": "/img/sidebar-5.jpg"
  }
];